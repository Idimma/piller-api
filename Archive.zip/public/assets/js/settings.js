document.querySelector('.link-toggle').addEventListener('click', () => {
    toggleClass(document.querySelector('.link-toggle'),'active')
})