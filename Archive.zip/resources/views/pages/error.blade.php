<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="../assets/css/error.css">
    <title>Stokkpiler | Error page</title>
</head>
<body>
    <div class="header">
        <h2>
            Stokkpile.com
        </h2>
    </div>
    <main>
        <div class="text-content">
            <h1>
                Oops!!
            </h1>
            <p>
                Looks like something went wrong, please be calm. we are working on it and it and on the page would be available shortly.
            </p>
            <div class="button-group">
                <button class="refresh btn">
                    Refresh
                </button>
                <a href="../index.html" class="homepage-link btn">
                    Homepage
                </a>
            </div>
        </div>
        <img src="../assets/images/error.svg" alt="error-img" class="error-img">
    </main>
</body>
</html>
