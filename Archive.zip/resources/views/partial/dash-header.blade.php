{{--<div class="top">--}}
{{--    <button class="sidenav-btn">--}}
{{--        <div class="bar"></div>--}}
{{--        <div class="bar"></div>--}}
{{--        <div class="bar"></div>--}}
{{--    </button>--}}
{{--    <div class="back">--}}
{{--        <!--<img src="../assets/images/back.svg" alt="">-->--}}
{{--        <!--<a href="">Back</a>-->--}}
{{--    </div>--}}
{{--    <table class="rates">--}}
{{--        <tr>--}}
{{--            <td>Rates</td>--}}
{{--            <td>Block</td>--}}
{{--            <td>Cement</td>--}}
{{--        </tr>--}}
{{--        <tr>--}}
{{--            <td>Local</td>--}}
{{--            <td>--}}
{{--                <img src="../assets/images/rate-down.svg" alt="">--}}
{{--                &#8358 200--}}
{{--            </td>--}}
{{--            <td>--}}
{{--                <img src="../assets/images/rate-up.svg" alt="">--}}
{{--                &#8358 2000--}}
{{--            </td>--}}
{{--        </tr>--}}
{{--        <tr>--}}
{{--            <td>International</td>--}}
{{--            <td>--}}
{{--                <img src="../assets/images/rate-down.svg" alt="">--}}
{{--                $2--}}
{{--            </td>--}}
{{--            <td>--}}
{{--                <img src="../assets/images/rate-up.svg" alt="">--}}
{{--                $2--}}
{{--            </td>--}}
{{--        </tr>--}}
{{--    </table>--}}
{{--    <div class="user-controls">--}}
{{--        <div class="notifications">--}}

{{--        </div>--}}
{{--        <a class="user" href="{{url('settings')}}">--}}
{{--            <img src="{{ auth()->user()->avatar_url}}" alt="">--}}
{{--        </a>--}}
{{--        <a class="logout" href="{{url('logout')}}">Logout</a>--}}
{{--    </div>--}}
{{--</div>--}}

<div class="top">
    <button class="sidenav-btn">
        <div class="bar"></div>
        <div class="bar"></div>
        <div class="bar"></div>
    </button>
    <div class="back">
        <img src="../assets/images/back.svg" alt="">
        <a href="">Back</a>
    </div>
    <table class="rates">
        <tr>
            <td>Rates</td>
            <td>Block</td>
            <td>Cement</td>
        </tr>
        <tr>
            <td>Local</td>
            <td>
                <img src="../assets/images/rate-down.svg" alt="">
                &#8358; 200
            </td>
            <td>
                <img src="../assets/images/rate-up.svg" alt="">
                &#8358; 2000
            </td>
        </tr>
        <tr>
            <td>International</td>
            <td>
                <img src="../assets/images/rate-down.svg" alt="">
                $2
            </td>
            <td>
                <img src="../assets/images/rate-up.svg" alt="">
                $2
            </td>
        </tr>
    </table>
    <div class="user-controls">
        <!--  <div class="notifications">

         </div> -->
        <a class="user" href="./settings.html">
            <img src="../assets/images/user.svg" alt="">
        </a>
        <a class="logout" href="#">Logout</a>
    </div>
</div>
